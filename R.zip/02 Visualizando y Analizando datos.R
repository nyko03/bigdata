#volvemos a cargar los datos del ejercicio anterior para limpiar

mysource <- file.path(rxGetOption("sampleDataDir"), "AirlineDemoSmall.csv")

colInfo <- list(DayOfWeek = list(type = "factor",
                                 levels = c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")))

airXdfData <- rxImport(inData=mysource, outFile="c:/Users/Temp/airExample.xdf", missingValueString="M", 
                       rowsPerRead=200000, colInfo  = colInfo, colClasses=c(ArrDelay="integer"), overwrite=TRUE)

airXdfData <- rxDataStep(inData = airXdfData, outFile = "c:/Users/Temp/airExample.xdf",
                         transforms=list(VeryLate = (ArrDelay > 120 | is.na(ArrDelay))), overwrite = TRUE)

airExtraDS <- rxDataStep(inData=airXdfData, outFile="c:/users/temp/ADS2.xdf",
                         transforms=list(
                           Late = ArrDelay > 15,
                           DepHour = as.integer(CRSDepTime),
                           Night = DepHour >= 20 | DepHour <= 5), overwrite=TRUE)

rxGetInfo(airExtraDS, getVarInfo=TRUE, numRows=5)
rxGetInfo(airXdfData, getVarInfo=TRUE)

#Usamos la función rxLinMod para cargar un modelo lineal con una única variable dependiente , el factor DayOfWeek

arrDelayLm1 <- rxLinMod(ArrDelay ~ DayOfWeek, data=airXdfData)
summary(arrDelayLm1)

#Usamos el argumento cube para realizar una partición inversa que sería más rápida y utilizaría menos memoria
#Los coeficientes estimados son la media de llegada para cada día de la semana

arrDelayLm2 <- rxLinMod(ArrDelay ~ DayOfWeek, data = airXdfData,
                        cube = TRUE)
summary(arrDelayLm2)

#podemos extraer del resultado countDF
countsDF <- rxResultsDF(arrDelayLm2, type = "counts")
countsDF

#lo mostramos en un plot
rxLinePlot(ArrDelay~DayOfWeek, data = countsDF,
           main = "Average Arrival Delay by Day of Week")


arrDelayLm3 <- rxLinMod(ArrDelay ~ DayOfWeek:F(CRSDepTime),
                        data = airXdfData, cube = TRUE)
arrDelayDT <- rxResultsDF(arrDelayLm3, type = "counts")
head(arrDelayDT, 15)

rxLinePlot( ArrDelay~CRSDepTime|DayOfWeek, data = arrDelayDT,
            title = "Average Arrival Delay by Day of Week by Departure Hour")


airLateDS <- rxDataStep(inData = airXdfData, outFile = "c:/Users/Temp/ADS1.xdf",
                        varsToDrop = c("CRSDepTime"),
                        rowSelection = ArrDelay > 15)
ncol(airLateDS)
nrow(airLateDS)

myTab <- rxCrossTabs(ArrDelay~DayOfWeek, data = airLateDS)
summary(myTab, output = "means")

#Regresión logística

logitObj <- rxLogit(Late~DepHour + Night, data = airExtraDS)
summary(logitObj)

#estimamos si el vuelo estará muy retrasado dependiendo del día de la semana
logitResults <- rxLogit(VeryLate ~ DayOfWeek, data = airXdfData )
summary(logitResults)


logitResults2 <- rxLogit(VeryLate ~ DayOfWeek - 1, data = airXdfData )
summary(logitResults2)

logitResults2 <- rxLogit(VeryLate ~ DayOfWeek - 1, data = airXdfData )
summary(logitResults2)



predictDS <- rxPredict(modelObject = logitObj, data = airExtraDS,
                       outData = airExtraDS)
rxGetInfo(predictDS, getVarInfo=TRUE, numRows=5)