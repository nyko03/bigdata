# IMPORTANDO DATOS a R

#El fichero AirlineDemoSmall.csv es el que vamos a utilizar en este laboratorio. 
# Es un subconjunto de un dataset más grande que contiene información de llegadas y salidas de vuelos para todos los vuelos en USA
#desde Octubre de 1987 hasta Abril de 2008
#El fichero contiene tres columnas de datos: ArrDelay, CRSDepTime, y DayOfWeek con un total de 600.000 filas

#Reinicia la sesión R para que el contexto sea "local". Puedes hacerlo desde el menú Session

#Cargamos los datos del CSV
mysource <- file.path(rxGetOption("sampleDataDir"), "AirlineDemoSmall.csv")
airXdfData <- rxImport(inData=mysource)

#Cargmos los datos y persistimo u xdf
airXdfData <- rxImport(inData=mysource, outFile="/tmp/airExample.xdf")

#vemos información sobre ese xdf generado
rxGetInfo(airXdfData, getVarInfo = TRUE)

#modificamos el proceso de carga para especificar otros valores de filas cargadas, etc.

airXdfData <- rxImport(inData=mysource, outFile="/tmp/airExample.xdf",
                       stringsAsFactors=TRUE, missingValueString="M", rowsPerRead=200000,
                       overwrite=TRUE)
#Especificamos información y tipo de datos factor de una columna para aplicarlo en la carga
colInfo <- list(DayOfWeek = list(type = "factor",
                                 levels = c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")))

airXdfData <- rxImport(inData=mysource, outFile="/tmp/airExample.xdf", missingValueString="M", 
                       rowsPerRead=200000, colInfo  = colInfo, colClasses=c(ArrDelay="integer"),
                       overwrite=TRUE)

#Mostramos información en Histograma
rxHistogram(~ArrDelay|DayOfWeek,  data = airXdfData)

#Mostramos información resumida del xdf
rxSummary(~ ArrDelay, data = airXdfData)

#Cargamos de nuevo aplicando una transformación
airXdfData <- rxDataStep(inData = airXdfData, outFile = "/tmp/airExample.xdf",
                         transforms=list(VeryLate = (ArrDelay > 120 | is.na(ArrDelay))),
                         overwrite = TRUE)
#Mostramos información sobre los datos cargados
rxGetInfo(airXdfData, getVarInfo = TRUE)

rxSummary(~ArrDelay+CRSDepTime+DayOfWeek, data=airXdfData)

#Estadísticas por categoría
rxSummary(~ArrDelay:DayOfWeek, data=airXdfData)

#ejecutamos un histograma de cada vez para tener mejor idea de los datos
rxHistogram(~ArrDelay, data=airXdfData)
rxHistogram(~CRSDepTime, data=airXdfData)
rxHistogram(~DayOfWeek, data=airXdfData)

#Extraemos un subconjunto de datos a una estructura en memoria

myData <- rxDataStep(inData = airXdfData,
                     rowSelection = ArrDelay > 240 & ArrDelay <= 300,
                     varsToKeep = c("ArrDelay", "DayOfWeek"))
#Motramos histograma
rxHistogram(~ArrDelay, data = myData)
#Información sobre los datos
nrow(airXdfData)
ncol(airXdfData)
head(airXdfData)
#Creamos un nuevo dataset con 10 filas a partir de 100.000
airXdfDataSmall <- rxDataStep(inData=airXdfData, numRows=10, startRow=100000)
airXdfDataSmall

#Transformamos variables
# Late variable lógica que es TRUE si se ha retrasado más de 15 min
#DepHour hora de salida como variable entera
#Night variable lógica que es TRUE si el vuelo ha salido entre 8 pm  y 5 am
airExtraDS <- rxDataStep(inData=airXdfData, outFile="/tmp/ADS2.xdf",
                         transforms=list(
                           Late = ArrDelay > 15,
                           DepHour = as.integer(CRSDepTime),
                           Night = DepHour >= 20 | DepHour <= 5))

rxGetInfo(airExtraDS, getVarInfo=TRUE, numRows=5)
